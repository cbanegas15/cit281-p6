// Shape class
class Shape {
    constructor(sides = []) {
      this.sides = sides;
    }
  
    perimeter() {
      return this.sides.length > 0 ? this.sides.reduce((acc, val) => acc + val, 0) : 0;
    }
  }
  
  // Rectangle class
  class Rectangle extends Shape {
    constructor(length = 0, width = 0) {
      super([length, width, length, width]);
      this.length = length;
      this.width = width;
    }
  
    area() {
      return this.length * this.width;
    }
  }
  
  // Triangle class
  class Triangle extends Shape {
    constructor(sideA = 0, sideB = 0, sideC = 0) {
      super([sideA, sideB, sideC]);
      this.sideA = sideA;
      this.sideB = sideB;
      this.sideC = sideC;
    }
  
    area() {
      const s = (this.sideA + this.sideB + this.sideC) / 2;
      return Math.sqrt(s * (s - this.sideA) * (s - this.sideB) * (s - this.sideC));
    }
  }
  
  // Test the Rectangle class
  console.log(new Rectangle(4, 4).perimeter());  // Expected output: 16
  console.log(new Rectangle(4, 4).area());  // Expected output: 16
  console.log(new Rectangle(5, 5).perimeter()); // Expected output: 20
  console.log(new Rectangle(5, 5).area()); // Expected output: 25
  console.log(new Rectangle().perimeter()); // Expected output: 0
  console.log(new Rectangle().area()); // Expected output: 0
  
  // Test the Triangle class
  console.log(new Triangle(3, 4, 5).perimeter());  // Expected output: 12
  console.log(new Triangle(3, 4, 5).area());  // Expected output: 6
  console.log(new Triangle().perimeter()); // Expected output: 0
  console.log(new Triangle().area()); // Expected output: 0
  
  